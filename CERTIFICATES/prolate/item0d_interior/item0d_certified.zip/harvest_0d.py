"""Harvest checkpoint_0d failed_terminal boxes via interval Riemann F>0; append to riemann_0d.json."""
import json, sys, time
from riemann_rescue import riemann_F
from flint import arb
budget = int(sys.argv[1]) if len(sys.argv)>1 else 200
d = json.load(open('checkpoint_0d.json'))
try: out = json.load(open('riemann_0d.json'))
except FileNotFoundError: out = {"label":"F_positive_riemann","stage":"0d","records":[]}
t_end = time.time()+budget; remaining=[]
for x in d['failed_terminal']:
    if time.time()>t_end: remaining.append(x); continue
    b=x['box']; done=False
    for N in (384,512):
        v=riemann_F(b['r'][0],b['r'][1],b['lambda'][0],b['lambda'][1],N)
        lo=arb(v.real.lower())
        if lo>0:
            out['records'].append({"box":b,"label":"F_positive_riemann","result":{"positive_certified":True,"real_lower":str(lo),"real_upper":str(arb(v.real.upper())),"method":{"type":"interval_riemann_midcell","N":N,"dps":25}}})
            done=True; break
    if not done: remaining.append(x)
d['failed_terminal']=remaining
d.setdefault('events',[]).append({"action":"harvest_terminals_riemann_0d","rescued":len(out['records'])})
json.dump(d,open('checkpoint_0d.json','w')); json.dump(out,open('riemann_0d.json','w'))
print(f"rescued_total={len(out['records'])} still_terminal={len(remaining)}")
