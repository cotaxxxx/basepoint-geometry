"""Harvest failed_terminal boxes from checkpoint_0d.json and certify F>0 on
each by the whole-cell interval Riemann method (riemann_rescue.riemann_F).
Successful boxes move to riemann_patch_0d.json; failures stay terminal."""
import json, sys, time
from riemann_rescue import riemann_F
from flint import arb

def main(budget):
    d = json.load(open('checkpoint_0d.json'))
    try: patch = json.load(open('riemann_patch_0d.json'))
    except FileNotFoundError: patch = {"label":"F_positive_riemann","stage":"0d","records":[]}
    t_end = time.time()+budget
    remain=[]
    for x in d['failed_terminal']:
        if time.time() > t_end: remain.append(x); continue
        b = x['box']; done=False
        for N in (384,512):
            v = riemann_F(b['r'][0],b['r'][1],b['lambda'][0],b['lambda'][1],N)
            lo = arb(v.real.lower())
            if lo > 0:
                patch['records'].append({"box":b,"result":{"positive_certified":True,
                    "real_lower":str(lo),"real_upper":str(arb(v.real.upper())),
                    "method":{"type":"interval_riemann_midcell","N":N,"dps":25}}})
                done=True; break
        if not done: remain.append(x)
    d['failed_terminal']=remain
    d.setdefault('events',[]).append({"action":"riemann_rescue_0d","n_rescued":len(patch['records'])})
    json.dump(d,open('checkpoint_0d.json','w')); json.dump(patch,open('riemann_patch_0d.json','w'))
    print(f"rescued_total={len(patch['records'])} still_terminal={len(remain)}")
if __name__=="__main__": main(int(sys.argv[1]))
