"""Mixed runner for 0d: F (acb) -> F (interval Riemann N=384,512) -> halve(<=16) -> TERMINAL."""
import json, sys, time
from fractions import Fraction as Fr
from prolate_general_r_arb_kernels import evaluate_box
from riemann_rescue import riemann_F
from flint import arb
MAXDEPTH=16; TOL="5e-2"; DPS=30
def halve(b):
    rw=Fr(b['r'][1])-Fr(b['r'][0]); lw=Fr(b['lambda'][1])-Fr(b['lambda'][0])
    if rw>=lw:
        m=(Fr(b['r'][0])+Fr(b['r'][1]))/2
        return [{"r":[b['r'][0],str(m)],"lambda":b['lambda'],"depth":b['depth']+1},{"r":[str(m),b['r'][1]],"lambda":b['lambda'],"depth":b['depth']+1}]
    m=(Fr(b['lambda'][0])+Fr(b['lambda'][1]))/2
    return [{"r":b['r'],"lambda":[b['lambda'][0],str(m)],"depth":b['depth']+1},{"r":b['r'],"lambda":[str(m),b['lambda'][1]],"depth":b['depth']+1}]
def main(budget):
    q=json.load(open('mixed_queue_0d.json')); t_end=time.time()+budget
    while q['queue'] and time.time()<t_end:
        b=q['queue'].pop(0)
        res=evaluate_box("F",b['r'][0],b['r'][1],b['lambda'][0],b['lambda'][1],DPS,TOL,12,60000)
        if res['positive_certified']:
            q['records'].append({"box":b,"label":"F_positive","result":res})
        else:
            done=False
            for N in (384,512):
                v=riemann_F(b['r'][0],b['r'][1],b['lambda'][0],b['lambda'][1],N); lo=arb(v.real.lower())
                if lo>0:
                    q['records'].append({"box":b,"label":"F_positive_riemann","result":{"positive_certified":True,"real_lower":str(lo),"real_upper":str(arb(v.real.upper())),"method":{"type":"interval_riemann_midcell","N":N,"dps":25}}}); done=True; break
            if not done:
                if b['depth']<MAXDEPTH: q['queue']=halve(b)+q['queue']
                else: q['records'].append({"box":b,"label":"TERMINAL_FAILURE","result":res}); print("TERMINAL:",b)
        json.dump(q,open('mixed_queue_0d.json','w'))
    print(f"queue={len(q['queue'])} records={len(q['records'])}")
main(int(sys.argv[1]))
